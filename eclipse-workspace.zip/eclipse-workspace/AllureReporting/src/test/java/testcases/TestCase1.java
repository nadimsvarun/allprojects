package testcases;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;

public class TestCase1 {
	
	@Test
	@Description("Login Test")
	@Severity(SeverityLevel.CRITICAL)
	public void douserlogin() {
		
		System.out.println("test case passed");
		
	}
	
	@Test
	@Description("User Reg Test")
	@Severity(SeverityLevel.BLOCKER)
	public void douserreg() {
		
		Assert.fail("test case failed");
	}
	
	@Test
	public void isskip() {
		
		throw new SkipException("skipping exception");
		
	}

}
