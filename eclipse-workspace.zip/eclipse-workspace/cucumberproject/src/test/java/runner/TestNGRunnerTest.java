package runner;



import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;
@CucumberOptions(features="src/test/resources/features",
glue={"stepdefs","hooks"},
plugin = {"pretty", "html:target/cucumber.html,summary"},
snippets=SnippetType.CAMELCASE,
monochrome=true,
tags="@scenario1 or @scenario2")
public class TestNGRunnerTest extends AbstractTestNGCucumberTests{



}

