package stepdefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Dummy {


	@Given("I want to test a test feature")
	public void i_want_to_test_a_test_feature() {
	    // Write code here that turns the phrase above into concrete actions

	}

	@When("I click on test feature")
	public void i_click_on_test_feature() {
	    // Write code here that turns the phrase above into concrete actions

	}

	@Then("test feature is clicked")
	public void test_feature_is_clicked() {
	    // Write code here that turns the phrase above into concrete actions

	}

	@Given("My account balance is ${int}")
	public void my_account_balance_is_$(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions

	}

	@When("I withdraw ${int}")
	public void i_withdraw_$(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions

	}

	@Then("the account balance should be ${int}")
	public void the_account_balance_should_be_$(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions

	}

}
