package stepdefs;

import io.cucumber.java.ParameterType;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Addtocart {

	@ParameterType(".*")
	public Products product(String name) {

		return new Products(name);
	}

	@Given("I am on the store page")
	public void iAmOnTheStorePage() {
	    // Write code here that turns the phrase above into concrete actions

	}
	@When("I add {product} to the cart")
	public void iAddToTheCart(Products product) {
	    // Write code here that turns the phrase above into concrete actions

	   System.out.println(product.getProductname());
	}
	@Then("I see {int} product(s) in the cart")
	public void iSeeInTheCart(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions

	}
	@Then("I clicked on plus to add one more product")
	public void i_clicked_on_plus_to_add_one_more_product() {
	    // Write code here that turns the phrase above into concrete actions

	}




}
