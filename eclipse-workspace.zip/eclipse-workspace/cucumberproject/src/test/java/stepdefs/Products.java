package stepdefs;

public class Products {

	private String productname;

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public Products(String productname) {

		this.productname = productname;
	}



}
