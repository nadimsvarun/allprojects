package hooks;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.BeforeStep;

public class Hooks {

	@BeforeAll
	public static void before_all() {

		System.out.println("@Before all -- create db connection");
	}

	@AfterAll
	public static void after_all() {

		System.out.println("@After all -- close db connection");


	}

	@Before
	public void setup() {

		System.out.println("@Before hook - launching browser");
	}

	@After
	public void teardown() {

		System.out.println("@After hook - closing browser");
	}

	@BeforeStep
	public void logsbeforestep() {

		System.out.println("@Before step - print logs");

	}

    @AfterStep
    public void logsafterstep() {

    	System.out.println("@After step - print logs");

	}

}
