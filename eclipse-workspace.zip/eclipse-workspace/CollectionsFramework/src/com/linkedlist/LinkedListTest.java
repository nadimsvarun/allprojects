package com.linkedlist;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<String> ll = new LinkedList<>();
		ll.add("test");
		ll.add("qtp");
		ll.add("selenium");
		ll.add("RPA");
		ll.add("RFT");

		System.out.println(ll);

		System.out.println(ll.get(0));
		System.out.println(ll.get(2));

		ll.addFirst("varun");
		ll.addLast("nadim");

		System.out.println(ll);

		ll.set(0, "apple");
		System.out.println(ll);

		ll.removeFirst();
		ll.removeLast();
		System.out.println(ll);

		ll.remove(2);
		System.out.println(ll);

		for (String element : ll) {

			System.out.println(element);
		}


		for(String x:ll) {

			System.out.println(x);
		}



		Iterator<String> it = ll.iterator();
		while(it.hasNext()) {

			System.out.println(it.next());
		}

	}

}
