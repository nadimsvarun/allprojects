package com.arraylist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class DemoArraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



			// TODO Auto-generated method stub

			ArrayList<String> ar = new ArrayList<>();

			ar.add("hello");
			ar.add("how");
			ar.add("are");
			ar.add("you");

			for(String a:ar) {

				System.out.println(a);
			}

			ar.stream().forEach(e->System.out.println(e));



		ArrayList<String> ar2 = new ArrayList<>();
		ar2.add("one");
		ar2.add("two");

		System.out.println(ar2);

		//ar.addAll(ar2);


		ar.addAll(2,ar2);
		System.out.println(ar);


		ArrayList<String> ar3 =  (ArrayList<String>) ar.clone();
		System.out.println(ar3);


		System.out.println(ar3.contains("how"));
		System.out.println(ar3.indexOf("you"));


		ArrayList<String> al = new ArrayList<>(Arrays.asList("apple","ball","cat","dog"));
		System.out.println(al.lastIndexOf("ball"));

		al.remove(1);
		System.out.println(al);

		al.remove("cat");
		System.out.println(al);


		ArrayList<Integer> al2 = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8));
		al2.removeIf(e->e%2==0);
		System.out.println(al2);


		ArrayList<String> al3 = new ArrayList<>(Arrays.asList("apple","ball","cat","dog","apple"));
		al3.retainAll(Collections.singleton("apple"));
		System.out.println(al3);

		ArrayList<Integer> al4 = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,8,1));
		ArrayList<Integer> al5 = new ArrayList<>(al4.subList(2, 7));
		System.out.println(al5);


		ArrayList<Integer> al6 = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,8,1));
		Object[]arr = al6.toArray();
		System.out.println(Arrays.toString(arr));








	}

}
