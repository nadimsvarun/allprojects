package com.arraylist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> al = new ArrayList<>(Arrays.asList(1,1,1,2,3,4,4,4,5,6,7,8,8,9));
		HashSet<Integer> hs = new HashSet<>(al);
		System.out.println(hs);


		ArrayList<Integer> al2 = new ArrayList<>(Arrays.asList(1,1,1,2,3,4,4,4,5,6,7,8,8,9));

		List<Integer> li = al2.stream().distinct().collect(Collectors.toList());
		System.out.println(li);

	}

}
