package com.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class SynchronizedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> namelist = Collections.synchronizedList(new ArrayList<String>());
		namelist.add("java");
		namelist.add("python");
		namelist.add("c#");
		namelist.add("C++");
		namelist.add(".Net");


		synchronized(namelist) {
		Iterator<String> it = namelist.iterator();
		while(it.hasNext()) {


			System.out.println(it.next());
		}
		}

		//CopyOnWriteArrayList
		CopyOnWriteArrayList<String> cwa = new CopyOnWriteArrayList<>();
		cwa.add("Tom");
		cwa.add("Robert");
		cwa.add("Mike");
		cwa.add("David");

		Iterator<String> it = cwa.iterator();
		while(it.hasNext()) {


			System.out.println(it.next());
		}

	}

}
