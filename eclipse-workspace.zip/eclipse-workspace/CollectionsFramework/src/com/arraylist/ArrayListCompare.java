package com.arraylist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class ArrayListCompare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String>al = new ArrayList<>(Arrays.asList("a","b","c","d","f","e"));
		Collections.sort(al);
		Collections.reverse(al);
		System.out.println(al);

		ArrayList<String>al2 = new ArrayList<>(Arrays.asList("a","b","c","d","f","e"));
		ArrayList<String>al3 = new ArrayList<>(Arrays.asList("a","b","c","d","g","h"));

		al2.removeAll(al3);

		System.out.println(al2);


		ArrayList<String>al4 = new ArrayList<>(Arrays.asList("one","two","three","four","five","six"));
		ArrayList<String>al5 = new ArrayList<>(Arrays.asList("one","two","three","four","seven","eight"));
        al4.retainAll(al5);
        System.out.println(al4);

      checkarrytolist();

	}

	public static void checkarrytolist() {

		int x[] = {10,1,20,3,2,99};

		List<Integer> lst = new ArrayList<Integer>();
		
		for(int num:x) {
			
			lst.add(num);
		}
		
		Collections.sort(lst);
		Collections.reverse(lst);
		System.out.println(lst);
	}

}
