package com.hashmap;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class HashMapCompare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		HashMap<Integer,String> hm = new HashMap<>();
		hm.put(1, "one");
		hm.put(2, "two");
		hm.put(3, "three");
		hm.put(4, "four");


		HashMap<Integer,String> hm2 = new HashMap<>();
		hm2.put(2, "two");
		hm2.put(4, "four");
		hm2.put(1, "one");
		hm2.put(3, "three");

		System.out.println(hm2.equals(hm));

		HashMap<Integer,String> hm3 = new HashMap<>();
		hm3.put(2, "two");
		hm3.put(4, "four");
		hm3.put(1, "one");
		hm3.put(3, "three");
		hm3.put(5, "five");

		System.out.println(hm3.equals(hm2));


		//find out extra keys in merged map


		//combine keys using hashset
		HashSet<Integer> ckeys = new HashSet<>(hm2.keySet());
		ckeys.addAll(hm3.keySet());
		ckeys.removeAll(hm2.keySet());
		System.out.println(ckeys);


		String s = "hearta";
		String  s2 = "earth";

		HashMap<Character,Integer> hmap1 = new HashMap<>();
		HashMap<Character,Integer> hmap2 = new HashMap<>();


		for(int i=0;i<s.length();i++) {

			if(hmap1.containsKey(s.charAt(i))) {

				hmap1.put(s.charAt(i), hmap1.get(s.charAt(i))+1);
			}else {

				hmap1.put(s.charAt(i),1);
			}
		}

	for(int i=0;i<s2.length();i++) {

			if(hmap2.containsKey(s2.charAt(i))) {

				hmap2.put(s2.charAt(i), hmap2.get(s2.charAt(i))+1);
			}else {

				hmap2.put(s2.charAt(i),1);
			}
		}




	for(Map.Entry<Character, Integer> hmp : hmap1.entrySet()) {

		System.out.println(hmp.getKey()+":"+hmp.getValue());

	}

	System.out.println(hmap1.equals(hmap2));

}
}
