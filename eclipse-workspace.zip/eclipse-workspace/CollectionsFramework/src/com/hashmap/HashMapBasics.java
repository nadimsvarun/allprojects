package com.hashmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapBasics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<String,String> hm = new HashMap<>();
		hm.put("AP", "Amaravati");
		hm.put("TG", "HYD");
		hm.put("KA", "BLR");
		hm.put("TN", "CHENNAI");
		hm.put(null, "NULL");
		hm.put("NULL1", null);
		hm.put("NULL2", null);


		System.out.println(hm);

		//iterator over keys

		for (String key : hm.keySet()) {

			String value = hm.get(key);
			System.out.println("key="+key+ ":"+"value="+value);
		}

		for (Entry<String, String> itnxt : hm.entrySet()) {

			 System.out.println(itnxt.getKey()+":"+itnxt.getValue());

		}

		hm.forEach((k,v) -> System.out.println("key="+k+"value="+v));


		List<String> lst = new ArrayList<>();


		for(Map.Entry<String, String> m: hm.entrySet()) {

			if(m.getValue().equals("HYD")) {

				lst.add(m.getKey());
			}
		}


	}



}
