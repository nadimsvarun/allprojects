package com.hashmap;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class HashMapInitialization {


	public static Map<String,Integer> marksmap;

	static {

		marksmap = new HashMap<>();
		marksmap.put("A", 100);
		marksmap.put("B", 200);
		marksmap.put("C", 300);


	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(HashMapInitialization.marksmap.get("A"));
		Map<String,Integer>map3 = Collections.singletonMap("varun", 100);

		Map<Object, Object> map2 = Stream.of(new Object[][] {
			{"Tom", 100},
			{"David", 200},

		}).collect(Collectors.toMap(data->data[0], data->data[1]));

	}

	//empty map
	Map<String,String> emptyMap = Map.of();

	//singleton map
	Map<String,String> singletonMap = Map.of("k1","v1");


}
