package page.actions;


import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import page.locators.CarSearch;
import utils.SeleniumDriver;

public class CarSearchPageActions {
	
	CarSearch cs = null;
	
	
	public CarSearchPageActions() {
		
		this.cs = new CarSearch();
		PageFactory.initElements(SeleniumDriver.getdriver(), cs);
	}
	
	public void selectmake(String make) {
		
		Select selmake = new Select(cs.selmake);
		selmake.selectByVisibleText(make);
		
	}
	
	public void selectmodel(String model) {
		
		Select selmodel = new Select(cs.selmodel);
		selmodel.selectByVisibleText(model);
	}
	
	public void selectstate(String state) {
		
		Select selstate = new Select(cs.selstate);
		selstate.selectByVisibleText(state);
	}
	
    public void selectregion(String region) {
		
		Select selregion = new Select(cs.selregion);
		selregion.selectByVisibleText(region);
	}
    public void selectprice(String price) {
		
  		Select selprice = new Select(cs.selmaxprice);
  		selprice.selectByVisibleText(price);
  	}
    
    public void clickshowvehiclebutton() {
    	
    	cs.clickbtn.click();
    }
	
    public void clickshownewvehiclebutton() {
    	
    	cs.clicknewbtn.click();
    }

}
