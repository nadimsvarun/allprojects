package page.actions;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import page.locators.CarsGuideHomePageLocators;
import utils.SeleniumDriver;

public class CarsGuideHomePageActions {
	
	CarsGuideHomePageLocators cghomepl = null;
	
	
	
	public CarsGuideHomePageActions() {

		this.cghomepl = new CarsGuideHomePageLocators();
		PageFactory.initElements(SeleniumDriver.getdriver(), cghomepl);
	}

	public void movetobuysellcarsmenu() {

		Actions act = new Actions(SeleniumDriver.getdriver());
		act.moveToElement(cghomepl.buysellacar).build().perform();
	}

	public void clicknewsearchcars() {
		
		cghomepl.newcar.click();

	}

	public void clickusedcars() {
		
		cghomepl.used.click();

	}

	public void clickonsellcar() {

		cghomepl.sellmycar.click();
	}
}
