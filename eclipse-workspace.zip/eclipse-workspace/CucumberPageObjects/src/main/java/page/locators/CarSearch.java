package page.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CarSearch {
	
	@FindBy(how=How.XPATH,using="//*[@id='make']")
	public WebElement selmake;
	
	@FindBy(how=How.XPATH,using="//*[@id='model']")
	public WebElement selmodel;
	
	@FindBy(how=How.XPATH,using="//*[@id='state']")
	public WebElement selstate;
	
	@FindBy(how=How.XPATH,using="//*[@id='region']")
	public WebElement selregion;
	
	@FindBy(how=How.XPATH,using="//*[@id='priceTo']")
	public WebElement selmaxprice;
	
	@FindBy(how=How.XPATH,using="//button[contains(text(),'Show used vehicles')]")
	public WebElement clickbtn;
	

	@FindBy(how=How.XPATH,using="//button[contains(text(),'Show new vehicles')]")
	public WebElement clicknewbtn;
	

}
