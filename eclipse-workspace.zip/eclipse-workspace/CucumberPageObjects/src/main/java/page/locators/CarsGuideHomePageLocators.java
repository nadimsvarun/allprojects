package page.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CarsGuideHomePageLocators {
	
	@FindBy(how=How.LINK_TEXT,using="buy + sell")
	public WebElement buysellacar;
	
	@FindBy(how=How.LINK_TEXT,using="Sell my car")
	public WebElement sellmycar;
	
	@FindBy(how=How.LINK_TEXT,using="reviews")
	public WebElement reviews;
	
	@FindBy(how=How.LINK_TEXT,using="Used")
	public WebElement used;
	
	@FindBy(how=How.LINK_TEXT,using="New")
	public WebElement newcar;

}
