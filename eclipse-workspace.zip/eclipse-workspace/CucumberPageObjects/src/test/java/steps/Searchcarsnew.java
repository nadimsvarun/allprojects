package steps;

import java.util.List;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import page.actions.CarSearchPageActions;
import page.actions.CarsGuideHomePageActions;
import utils.SeleniumDriver;

public class Searchcarsnew {
	
	CarsGuideHomePageActions cghpa = new CarsGuideHomePageActions();
	CarSearchPageActions cspa = new CarSearchPageActions();

	
	@And("select car model")
	public void select_car_model(List<String>model) {
	    String selmodel = model.get(2);
	   cspa.selectmodel(selmodel);
	    
	}
	

	@And("click on show new vehicles")
	public void click_on_show_new_vehicles() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   cspa.clickshownewvehiclebutton();
	   Thread.sleep(3000);
	}

	@And("I should see the list of new cars")
	public void i_should_see_the_list_of_new_cars() {
		
		 System.out.println("cars list found");
	   
	}
	
	@And("the new search page title should be {string}")
	public void the_new_search_page_title_should_be(String exptitle) {
	    // Write code here that turns the phrase above into concrete actions
	   String acttitle = SeleniumDriver.getdriver().getTitle();
	   Assert.assertEquals(acttitle, exptitle);
	}
}
