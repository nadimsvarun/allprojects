package steps;

import java.util.List;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page.actions.CarSearchPageActions;
import page.actions.CarsGuideHomePageActions;
import utils.SeleniumDriver;

public class Searchcarsteps {
	
	CarsGuideHomePageActions cghpa = new CarsGuideHomePageActions();
	CarSearchPageActions cspa = new CarSearchPageActions();
	String ctype=null;
	
	@Given("I am on the home page {string} of carsguide website")
	public void i_am_on_the_home_page_of_carsguide_website(String url) {
	    // Write code here that turns the phrase above into concrete actions
	    SeleniumDriver.openpage(url);
	}

	@When("I move to the menu")
	public void i_move_to_the_menu(List<String> list) {
	    String menu = list.get(1);
	    cghpa.movetobuysellcarsmenu();
	   
	}

	@And("click on {string} cars link")
	public void click_on_cars_link(String type) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		ctype=type;
		if(type.equalsIgnoreCase("Used")) {
	               
			cghpa.clickusedcars();
			
		}else {
			
			cghpa.clicknewsearchcars();
			
		}
	   Thread.sleep(3000);
	}

	@And("select car make as {string}")
	public void select_car_make_as(String make) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   cspa.selectmake(make);
	   Thread.sleep(3000);
	}

	@And("select car model as {string}")
	public void select_car_model_as(String model) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		cspa.selectmodel(model);
		 Thread.sleep(3000);
	   
	}

	@And("select state as {string}")
	public void select_state_as(String state) {
	    // Write code here that turns the phrase above into concrete actions
	  cspa.selectstate(state);
	}

	@And("select region as {string}")
	public void select_region_as(String region) {
	    // Write code here that turns the phrase above into concrete actions
	   cspa.selectregion(region);
	}

	@And("select price as {string}")
	public void select_price_as(String price) {
	    // Write code here that turns the phrase above into concrete actions
	   cspa.selectprice(price);
	}

	@Then("click on show used vehicles")
	public void click_on_show_used_vehicles() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   cspa.clickshowvehiclebutton();
	   Thread.sleep(3000);
	}

	@And("I should see the list of used cars")
	public void i_should_see_the_list_of_used_cars() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("cars list found");
	}

	@And("the page title should be {string}")
	public void the_page_title_should_be(String exptitle) {
	    // Write code here that turns the phrase above into concrete actions
	   String acttitle = SeleniumDriver.getdriver().getTitle();
	   Assert.assertEquals(acttitle, exptitle);
	}


}
