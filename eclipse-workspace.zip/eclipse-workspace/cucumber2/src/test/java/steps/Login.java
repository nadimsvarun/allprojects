package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login {


	@Given("user navigates to the gmail website")
	public void user_navigates_to_the_gmail_website() {

		System.out.println("@Given - user navigates to gmail");
	}

	@When("user validates the address")
	public void user_validates_the_address() {
		System.out.println("@When - user validates the address");
	}

	@Then("user enters the {string} username")
	public void user_enters_the_username(String uname) {
		System.out.println("@Then - user enters "+uname+"username");
	}

	@And("user enters the {string} password")
	public void user_enters_the_password(String pwd) {
		System.out.println("@And - user enters the "+pwd+" password");
	}
	@And("user clicks on login")
	public void user_clicks_on_login() {
		System.out.println("@And - user clicks on login");
	}

}
