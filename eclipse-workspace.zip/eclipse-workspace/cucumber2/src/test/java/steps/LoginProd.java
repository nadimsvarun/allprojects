package steps;

import java.util.List;
import java.util.Map;

import io.cucumber.java.en.And;

public class LoginProd {

	@And("user validates the captcha")
	public void user_validates_the_captcha_image() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("user validates the captcha message");
	}

	@And("user enter firstname and lastname")
	public void user_enter_firstname_and_lastname(io.cucumber.datatable.DataTable dataTable) {

		System.out.println("user enters firstname and lastname");
		List<List<String>> dt =dataTable.asLists();
		System.out.println("First name is"+dt.get(0).get(0)+"Last name is"+dt.get(0).get(1));
		System.out.println("First name is"+dt.get(1).get(0)+"Last name is"+dt.get(1).get(1));



	}
	@And("user enter the firstname and lastname")
	public void user_enter_the_firstname_and_lastname(io.cucumber.datatable.DataTable dataTable) {

	/*
		System.out.println("user enters the firstname and lastname");
		List<Map<String,String>> map = dataTable.asMaps();
		System.out.println(map.get(0).get("firstname")+"Last name ="+map.get(0).get("lastname"));
		System.out.println(map.get(1).get("firstname")+"Last name ="+map.get(1).get("lastname"));
		*/

		System.out.println("user enters the firstname and lastname");
	    for(Map<String,String> data: dataTable.asMaps(String.class,String.class)){

	    	System.out.println("First name is"+data.get("firstname")+"Last name is"+data.get("lastname"));
	    }
	}


}
