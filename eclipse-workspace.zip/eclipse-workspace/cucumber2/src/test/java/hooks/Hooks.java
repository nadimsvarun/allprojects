package hooks;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.BeforeStep;

public class Hooks {

	@BeforeAll
	public static void before_all() {

		System.out.println("connecting to db");

	}
	@AfterAll
  public static void after_all() {

		System.out.println("closing the db");

	}

	@Before("@staging")
	public void setup() {

		System.out.println("open the browser");

	}
	@After("@staging")
	public void teardown() {

		System.out.println("close the browser");
	}

	/*
	 * @Before(order=0) public void setup() {
	 *
	 * System.out.println("launchin the browser"); }
	 *
	 * @Before(order=1) public void setup1() {
	 *
	 * System.out.println("launchin the browser 2"); }
	 *
	 * @After(order=1) public void teardown() {
	 *
	 * System.out.println("closing the browser"); }
	 *
	 * @After(order=0) public void teardown2() {
	 *
	 * System.out.println("closing the browser 2"); }
	 */
	@BeforeStep
	public void before_step() {
		System.out.println("adding a log");

	}
	@AfterStep
	public void after_step() {

		System.out.println("deleting a log");
	}


}
