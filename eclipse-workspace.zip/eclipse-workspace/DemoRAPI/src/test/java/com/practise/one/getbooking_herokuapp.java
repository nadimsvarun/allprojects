package com.practise.one;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.pojoserialize.heroku_creds;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class getbooking_herokuapp {


	@Test
	public void getbookingtoken() {

		heroku_creds hcreds = new heroku_creds("admin", "password123");

		RestAssured.baseURI ="https://restful-booker.herokuapp.com";

		Response resp = given().log().all().contentType(ContentType.JSON).body(hcreds).when().log().all().post("/auth").then().assertThat().statusCode(200).and().extract().response();
		System.out.println(resp.asPrettyString());
		String token = resp.path("token");
		System.out.println(token);
	}


}
