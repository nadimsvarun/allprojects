package com.practise.one;

import static io.restassured.RestAssured.given;

import java.util.List;

import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Cirucits {


	@Test
	public void circuitdatabyyear() {

		RestAssured.baseURI="http://ergast.com";

		Response Res = given().log().all().when().log().all().get("/api/f1/2021/circuits.json");
		String jsonresponse =  Res.asString();
		System.out.println(jsonresponse);
		List<String> countries = JsonPath.read(jsonresponse, "$..CircuitTable.Circuits..country");
		System.out.println(countries);


	}

	@Test
	public void getproducts() {

         RestAssured.baseURI="https://fakestoreapi.com";

		Response Res = given().log().all().when().log().all().get("/products");
		String jsonresponse =  Res.asString();
		//System.out.println(jsonresponse);

		List<Object> tprice = JsonPath.read(jsonresponse,"$[?(@.category=='jewelery')].[\"title\",\"price\"]");
		System.out.println(tprice);
		System.out.println(RestAssured.get("price"));
	}

}
