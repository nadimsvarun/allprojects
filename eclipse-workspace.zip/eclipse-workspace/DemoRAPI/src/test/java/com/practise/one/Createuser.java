package com.practise.one;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.UUID;

import org.testng.annotations.Test;

import com.pojoserialize.Createuserpojo;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;


public class Createuser {

	public static String randomemail() {

		//return "nadimvarun"+System.currentTimeMillis()+"@yopmail.com";

		return "nadimvarun"+UUID.randomUUID()+"@yopmail.com";


	}


	@Test
	public void addusertest() {

		Createuserpojo cu = new Createuserpojo("nadimvarun", randomemail(), "male", "active");

		RestAssured.baseURI="https://gorest.co.in/";

		int id = given().log().all().contentType(ContentType.JSON).header("Authorization","Bearer c4b8fcedce9d3be94091db086cdcdf5127423671b50ae55ed88076230cb56777")
		.body(cu).when().post("public/v2/users").then().assertThat().statusCode(201).and().body("name", equalTo(cu.getName())).and().extract().path("id");



		//get the user

		given().log().all().contentType(ContentType.JSON).header("Authorization","Bearer c4b8fcedce9d3be94091db086cdcdf5127423671b50ae55ed88076230cb56777")
		.when().log().all().get("public/v2/users/"+id).then().assertThat().statusCode(200).and().body("id",equalTo(id)).and().body("email", equalTo(cu.getEmail())).and()
		.body("status", equalTo(cu.getStatus()));


	}



}
