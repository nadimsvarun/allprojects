package datatypes;

import java.util.LinkedList;

public class linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Integer> list = new LinkedList<>();
		list.add(100);
		list.add(200);
		list.add(300);
		System.out.println(list);

		list.set(1, 300);
		System.out.println(list);

		System.out.println(list.get(0));
		list.remove(2);
		System.out.println(list);

	}

}
