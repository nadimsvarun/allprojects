package datatypes;

import java.util.HashSet;
import java.util.Iterator;

public class Hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Integer> set = new HashSet<>();
		set.add(10);
		set.add(200);
		set.add(20001);
		set.add(null);
		set.add(10);
		set.add(null);
		System.out.println(set);

		Iterator<Integer> it = set.iterator();
		//System.out.println(it.next());

		while(it.hasNext()) {

			System.out.println(it.next());
		}

		for(Integer i:set) {

			System.out.println(i);

		}


	}

}
