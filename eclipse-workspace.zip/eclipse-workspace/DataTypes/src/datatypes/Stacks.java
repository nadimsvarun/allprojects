package datatypes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

public class Stacks {


	public static void main(String[] args) throws NumberFormatException, IOException {


		Stack<Integer>stack = new Stack<>();
	    int choice = 0;

	    BufferedReader br = new BufferedReader( new InputStreamReader(System.in));


	    while(choice<4) {

	    	System.out.println("stack operations");
	    	System.out.println("1.push an element");
	    	System.out.println("2.pop an element");
	    	System.out.println("3.search an element");
	    	System.out.println("4.extit");

	    	int choice1 = Integer.parseInt(br.readLine());

	    	switch(choice1){

	    	case 1: System.out.println("Enter an element");
	    	    int ele = Integer.parseInt(br.readLine());
	    	    stack.push(ele);
	    		break;

	    	case 2:
	    		  Integer elepop = stack.pop();
	    		  System.out.println("ele popped out"+elepop);
	    		  break;

	    	case 3:
	    		System.out.println("search for an element");
	    		int ele2 = Integer.parseInt(br.readLine());
	    		 int pos = stack.search(ele2);
	    		 System.out.println("position is"+ pos);
	    		 break;

	    	default:
	    		return;

	    	}

	    	System.out.println("stack contents="+stack);

	    }


	}
}
