package datatypes;

import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> alist = new ArrayList<>();

		alist.add(100);
		alist.add(101);
		alist.add(1);

		System.out.println(alist);

		System.out.println(alist.get(0));
		alist.size();

	}

}
