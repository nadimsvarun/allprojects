package datatypes;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Occurenceofcharacter {



	public static void main(String[] args) {


	String s = "geeksforgeeks";


	//System.out.println(s.length());

	//13

	//System.out.println(s.charAt(0));

String x = 	s.replace(String.valueOf(s.charAt(0)), "");

//System.out.println(x);

Map<Character, Integer> result= countmaxoccurence();

 for(Entry<Character, Integer> x2 : result.entrySet()) {

		System.out.println(x2.getKey()+""+ x2.getValue());
	}

 }


	public static Map<Character, Integer> countmaxoccurence() {

		String s = "geeksforgeeks";
		Map<Character,Integer>max = new HashMap<>();

		System.out.println(String.valueOf(0));

		max.put(s.charAt(0), s.length()-s.replace(String.valueOf(s.charAt(0)), "").length());

		System.out.println(s);

		for(char i : s.toCharArray()) {

			int count = s.length()-s.replace(String.valueOf(i), "").length();

			System.out.println(count);

			System.out.println(max.get(max.keySet().iterator().next()));

			if(count>max.get(max.keySet().iterator().next())){

				max.clear();
				max.put(i, count);
			}

		}

		return max;
	}
}
