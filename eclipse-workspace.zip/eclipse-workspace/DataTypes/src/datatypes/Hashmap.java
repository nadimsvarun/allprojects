package datatypes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<Integer,String> hmap = new HashMap<>();

		hmap.put(1, "apple");
		hmap.put(2, "orange");
		hmap.put(3, "guava");


		//hmap.put(null, "grapes");
		//hmap.put(4, null);
		//hmap.put(null, "orange");
		System.out.println(hmap);

		System.out.println(hmap.containsKey(3));
		System.out.println(hmap.containsValue("apple"));

		System.out.println(hmap.get(1));
		Set<Integer> keys = hmap.keySet();

		for( Entry<Integer, String> val: hmap.entrySet()){



				//System.out.println(val.getValue());
				//System.out.println(val.getKey());

				if(val.getKey()==2) {

					System.out.println(val.getValue());
				}

	}

		List<Integer> keys1 = hmap.entrySet().stream().filter(e-> e.getValue().startsWith("apple"))
				.map(Map.Entry::getKey).collect(Collectors.toList());

		System.out.println(keys1);

		List<Integer> keys2 = hmap.entrySet().stream().filter(e->e.getValue().startsWith("guava"))
				.map(Map.Entry::getKey).collect(Collectors.toList());



	}

}
