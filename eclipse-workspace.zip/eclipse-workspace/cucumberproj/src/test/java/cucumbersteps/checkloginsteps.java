package cucumbersteps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class checkloginsteps {
	
	
	@Given("user navigates to facebook page")
	public void user_navigates_to_facebook_page() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("@Given - user navigates to facebook");
	}

	@When("user validates the homepage title")
	public void user_validates_the_homepage_title() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("@When - user validates the homepage title");
	}

	@Then("user enters the valid username")
	public void user_enters_the_valid_username() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("@Then - user enters the username");
	}

	@Then("user enters the valid password")
	public void user_enters_the_valid_password() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("@Then - user enters the password");
	}

	@Then("user should log in successfully")
	public void user_should_log_in_successfully() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("@Then - user should log in sucessfully");
	}


}
