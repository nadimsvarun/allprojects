package com.df.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.df.utilities.Elementsutil;
import com.df.utilities.Excel;


public class TestBase {

	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
    public static Logger log = Logger.getLogger("devpinoyLogger");
    public static Elementsutil eutil ;
    public static Excel ex = new Excel(System.getProperty("user.dir")+"\\src\\test\\resources\\excel\\testdata.xlsx");
    public static WebDriverWait wait;



	@BeforeSuite
	public void setup() {
		PropertyConfigurator.configure(".\\src\\test\\resources\\properties\\log4j.properties");
	    log = Logger.getLogger("devpinoyLogger");



		if(driver==null) {




			try {
				fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\Config.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        try {
				config.load(fis);
				log.debug("config file loaded");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        System.out.println(config.getProperty("browser"));


	       try {
			fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\OR.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        try {
				OR.load(fis);
				log.debug("OR file loaded");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	        if(config.getProperty("browser").equalsIgnoreCase("chrome")) {

	        	driver=new ChromeDriver();
	        }

	        eutil = new Elementsutil(driver);
	        wait = new WebDriverWait(driver,Duration.ofSeconds(10));

	        driver.get(config.getProperty("url"));
	        log.debug("URL launched");
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Integer.parseInt(config.getProperty("implicitwait"))));

		}


	}


	@AfterSuite
	public void teardown() {

		driver.quit();
	}

}
