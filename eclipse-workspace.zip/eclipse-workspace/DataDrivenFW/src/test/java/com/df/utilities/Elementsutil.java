package com.df.utilities;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Elementsutil {

	private WebDriver driver;

	public Elementsutil(WebDriver driver) {

		this.driver=driver;

	}




public WebElement returnele(By by) {
	waitforele(by);
	return driver.findElement(by);
}

public void waitforele(By by) {

	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	wait.until(ExpectedConditions.visibilityOfElementLocated(by));
}
public boolean presenceofelement(By by) {

  return driver.findElement(by).isDisplayed();


}

}