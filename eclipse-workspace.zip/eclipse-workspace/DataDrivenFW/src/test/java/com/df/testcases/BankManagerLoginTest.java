package com.df.testcases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.df.base.TestBase;

public class BankManagerLoginTest extends TestBase {

	@Test
	public void loginasbankmanager() {


		eutil.returnele(By.cssSelector(OR.getProperty("bmlBtn"))).click();
		//driver.findElement(By.cssSelector(OR.getProperty("bmlBtn"))).click();
		log.debug("bank mgr login button clicked");
		Assert.assertTrue(eutil.presenceofelement(By.cssSelector(OR.getProperty("addcustBtn"))));
	    Assert.fail("fail the test");
	}

}
