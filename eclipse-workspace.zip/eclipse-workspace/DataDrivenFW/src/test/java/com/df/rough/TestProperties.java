package com.df.rough;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestProperties {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		System.getProperty("user.dir");
		Properties config = new Properties();
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\Config.properties");
        config.load(fs);
        System.out.println(config.getProperty("browser"));

        Properties or = new Properties();
		FileInputStream fs2 = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\OR.properties");
        config.load(fs2);

	}

}
