package com.df.testcases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.df.base.TestBase;

public class AddCustomerTest extends TestBase{

	@Test(dataProvider="getdata")
	public void addcustomer(String fname,String lname,String pcode) throws InterruptedException {

		eutil.returnele(By.cssSelector(OR.getProperty("addcustBtn"))).click();
		eutil.returnele(By.cssSelector(OR.getProperty("firstname"))).sendKeys(fname);
		Thread.sleep(1000);
		eutil.returnele(By.cssSelector(OR.getProperty("lastname"))).sendKeys(lname);
		Thread.sleep(1000);
		eutil.returnele(By.cssSelector(OR.getProperty("postcode"))).sendKeys(pcode);
		Thread.sleep(1000);
		eutil.returnele(By.cssSelector(OR.getProperty("submit"))).click();
		Alert alt = wait.until(ExpectedConditions.alertIsPresent());
		Assert.assertTrue(alt.getText().contains("Customer added successfully"));
		alt.accept();
	}


	@DataProvider
	public Object[][] getdata() {

		String sheetname = "AddCustomerTest";
		int rows = ex.getrowcount(sheetname);
		int cols = ex.getColumnCount(sheetname);

		System.out.println("rowscount= "+rows);
		System.out.println("colsscount= "+cols);

		Object[][] data = new Object[rows-1][cols];

		for(int rowno=2; rowno<=rows;rowno++) {

			for(int colno=0;colno<cols;colno++) {

				data[rowno-2][colno] = ex.getcelldata(sheetname, colno, rowno);
			}
		}

		return data;
	}

}
