package com.df.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	private String path;
	FileInputStream fis;
	private XSSFWorkbook wb =null;
	private XSSFSheet sheet = null;
	private XSSFRow row = null;
	private XSSFCell cell = null;

	public Excel(String path) {

		this.path=path;
		try {
			fis = new FileInputStream(path);
			try {
				wb = new XSSFWorkbook(fis);
				sheet = wb.getSheetAt(0);
				//System.out.println("sheet name="+sheet);
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public int getrowcount(String sheetname) {
		int index = wb.getSheetIndex(sheetname);
		System.out.println("index="+index);
		if(index==-1) {

			return 0;

		}else {

			sheet = wb.getSheetAt(index);
			int rowno = sheet.getLastRowNum()+1;
			return rowno;

			}
		}

	public int getColumnCount(String sheetName){
		// check if sheet exists
		int index = wb.getSheetIndex(sheetName);
		if(index==-1) {

			return 0;

		}else {

			sheet = wb.getSheetAt(index);

			row = sheet.getRow(0);

		}

		if(row==null) {
			return -1;
		}

		return row.getLastCellNum();



	}

	public String getcelldata(String sheetname,String colname, int rowno) {
		String celltxt = null;
		String cellb=null;

		try {

			if(rowno<=0) {
				return "";
			}

			int index = wb.getSheetIndex(sheetname);
			if(index==-1) {
				return "";
			}

			int colno =-1;

			sheet = wb.getSheetAt(index);
			row = sheet.getRow(0);
			for(int i=0;i<row.getLastCellNum();i++) {

				if(row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colname)) {

					colno=i;
				}
			}

			if(colno==-1) {
				return "";
			}

			sheet = wb.getSheetAt(index);
			row = sheet.getRow(rowno-1);
			if(row==null) {
				return "";
			}

			cell = row.getCell(colno);

			if(cell==null) {
				return "";
			}

			if(cell.getCellType()==CellType.STRING) {
				return cell.getStringCellValue();

		    }else if(cell.getCellType()==CellType.NUMERIC) {
				celltxt = String.valueOf(cell.getNumericCellValue());
			    return celltxt;

		    }else {

		       cellb =  String.valueOf(cell.getBooleanCellValue());
		        return cellb;
		    }

		}catch(Exception e) {
			return "row or col no does not exist in excel";
		}



	}

	public String getcelldata(String sheetname,int colno,int rowno) {
		String celltxt = null;
		String cellb=null;
		try {

		if(rowno<=0) {
			return "";
		}

		int index = wb.getSheetIndex(sheetname);

		if(index==-1) {
			return "";
		}

		sheet = wb.getSheetAt(index);
		row = sheet.getRow(rowno-1);
		if(row==null) {
			return "";
		}
		cell = row.getCell(colno);

		if(cell==null) {
			return "";
		}

		if(cell.getCellType()==CellType.STRING) {
			return cell.getStringCellValue();

	    }else if(cell.getCellType()==CellType.NUMERIC) {
			celltxt = String.valueOf(cell.getNumericCellValue());
		    return celltxt;

	    }else {

	       cellb =  String.valueOf(cell.getBooleanCellValue());
	        return cellb;
	    }


		}catch(Exception e) {

			return "row or col no does not exist";
		}

	}

	}


