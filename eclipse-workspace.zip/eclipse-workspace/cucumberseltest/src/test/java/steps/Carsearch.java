package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Carsearch {
	
	WebDriver driver;
	
	@Before
	public void setup() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@After
	public void teardown() {
		
		driver.quit();
	}

	
	@Given("user enters the url of the homepage https:\\/\\/www.carsguide.com.au")
	public void user_enters_the_url_of_the_homepage_https_www_carsguide_com_au() {
	    // Write code here that turns the phrase above into concrete actions
	   driver.get("https://www.carsguide.com.au/");
	}

	@When("user moves to the menu")
	public void user_moves_to_the_menu() {
	    // Write code here that turns the phrase above into concrete actions
		
		WebElement menu = driver.findElement(By.cssSelector("a[href*=buy-a-car]"));
		new Actions(driver).moveToElement(menu).build().perform();
	   
	}

	@Then("user clicks on the new search")
	public void user_clicks_on_the_new_search() {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.linkText("New")).click();
	}


	@And("user enter the make {string}")
	public void user_enter_the_make(String make) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	     new Select(driver.findElement(By.id("make"))).selectByVisibleText(make);
	     Thread.sleep(3000);
	}

	@And("user enters the model {string}")
	public void user_enters_the_model(String model) {
	    // Write code here that turns the phrase above into concrete actions
		 new Select(driver.findElement(By.id("model"))).selectByVisibleText(model);
	}

	@And("user selects the state {string}")
	public void user_selects_the_state(String state) {
	    // Write code here that turns the phrase above into concrete actions
		 new Select(driver.findElement(By.id("state"))).selectByVisibleText(state);
		
	   
	}
	

	@And("user selects the region {string}")
	public void user_selects_the_region(String region) {
	    // Write code here that turns the phrase above into concrete actions
		 new Select(driver.findElement(By.id("region"))).selectByVisibleText(region);
	}

	@And("user selects price as {string}")
	public void user_selects_price_as(String price) {
	    // Write code here that turns the phrase above into concrete actions
		 new Select(driver.findElement(By.id("priceTo"))).selectByVisibleText(price);
	}

	@And("user clicks on search button")
	public void user_clicks_on_search_button() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   driver.findElement(By.xpath("//button[contains(text(),'Show new vehicles')]")).click();
	   Thread.sleep(3000);
	}

	@Then("user should see a list of new cars")
	public void user_should_see_a_list_of_new_cars() {
	    // Write code here that turns the phrase above into concrete actions
	  Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"__layout\"]/div/div[3]/section/div[2]/div/div/div[5]/section[1]/a/div/div[2]/div/h3/span[contains(text(),'BMW')]")).isDisplayed());
	}

	@And("title should be {string}")
	public void title_should_be(String expected) {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(driver.getTitle());
	    Assert.assertEquals(expected, driver.getTitle());
	}



}
