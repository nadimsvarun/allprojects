package calendar;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class shadowelement {

	public static <SearchContext> void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("chrome://downloads/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		WebElement root = driver.findElement(By.cssSelector("downloads-manager"));
	    org.openqa.selenium.SearchContext shadowroot1 = root.getShadowRoot();
		WebElement root2 = shadowroot1.findElement(By.cssSelector("downloads-toolbar"));
		org.openqa.selenium.SearchContext shadowroot2 = root2.getShadowRoot();
        WebElement root3 = shadowroot2.findElement(By.cssSelector("cr-toolbar"));
        org.openqa.selenium.SearchContext shadowroot3 = root3.getShadowRoot();
		WebElement root4 = shadowroot3.findElement(By.cssSelector("cr-toolbar-search-field"));
		 org.openqa.selenium.SearchContext shadowroot4 = root4.getShadowRoot();
		 shadowroot4.findElement(By.id("searchInput")).sendKeys("hello");
		



	    
	     
	     
		/*
		//SearchContext  shadowroot1 =  (SearchContext) ((JavascriptExecutor)driver).executeScript("return arguments[0].shadowRoot",root);
		
		//((By) shadowroot1).findElement((org.openqa.selenium.SearchContext) By.cssSelector("downloads-toolbar"));
		
		WebElement root2 = ((By) shadowroot1).findElement((org.openqa.selenium.SearchContext) By.cssSelector("downloads-toolbar"));
		
		SearchContext shadowroot2 = (SearchContext) ((JavascriptExecutor)driver).executeScript("return arguments[0].shadowRoot",root2);

        WebElement root3 = ((By) shadowroot2).findElement((org.openqa.selenium.SearchContext) By.cssSelector("cr-toolbar"));
		
        SearchContext shadowroot3 = (SearchContext) ((JavascriptExecutor)driver).executeScript("return arguments[0].shadowRoot",root3);
		
		
		 WebElement root4 = ((By) shadowroot3).findElement((org.openqa.selenium.SearchContext) By.cssSelector("cr-toolbar-search-field"));
			
		 SearchContext shadowroot4 = (SearchContext) ((JavascriptExecutor)driver).executeScript("return arguments[0].shadowRoot",root4);
		 
		((By) shadowroot4).findElement((org.openqa.selenium.SearchContext) By.id("searchInput")).sendKeys("hello");
		*/

	}

}
