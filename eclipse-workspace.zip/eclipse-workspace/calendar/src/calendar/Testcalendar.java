package calendar;

import java.time.Duration;
import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testcalendar {
	
	
	static int targetday=0;
	       static int targetmonth=0;
	       static int targetyear=0;
	       

   static int currentday=0;
           static int currentmonth=0;
           static int currentyear=0;
           
           static int jumpmonthsby=0;
           static boolean increment =true;
	           

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String datetoset = "07/03/2024";
		
		
		getcurrentdate();
		gettargetdate(datetoset);
		howmanymonthstojump(currentmonth,targetmonth);
		

	}
	
	public static void getcurrentdate() {
		
		Calendar cal = Calendar.getInstance();
		currentday = cal.get(Calendar.DAY_OF_MONTH);
		currentmonth = cal.get(Calendar.MONTH)+1;
		currentyear = cal.get(Calendar.YEAR);
		
		System.out.println(currentday +" "+ currentmonth+" "+currentyear);
		
	}
	
	public static void gettargetdate(String datetoset) {
		
		//String datetoset = "07/03/2024";
		
		int findex = datetoset.indexOf("/");
		int lindex = datetoset.lastIndexOf("/");
		//System.out.println(findex);
		//System.out.println(lindex);
		
		String day = datetoset.substring(0,findex);
		targetday=Integer.parseInt(day);
		
		
		String month = datetoset.substring(findex+1,lindex);
		targetmonth = Integer.parseInt(month);
		
		
		String year = datetoset.substring(lindex+1,datetoset.length());
		targetyear = Integer.parseInt(year);
		
		
		System.out.println(targetday +" "+targetmonth+" "+targetyear );
		
		
	}
	
	public static void howmanymonthstojump(int currentmonth,int targetmonth) {
		
		if((targetmonth-currentmonth)>0) {
			
			jumpmonthsby=targetmonth-currentmonth;
			
		}else {
			
			jumpmonthsby=currentmonth-targetmonth;
			increment=false;
		}
		
		System.out.println("months to jump "+jumpmonthsby);
		System.out.println("increment "+increment);
		
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.way2automation.com/way2auto_jquery/datepicker.php");
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(By.xpath("/html/body/p/input")).click();
		//*[@id="datepicker"]
		
		
		
	}
	
	

}
