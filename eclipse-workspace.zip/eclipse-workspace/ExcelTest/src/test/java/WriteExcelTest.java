import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcelTest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet0 = workbook.createSheet("firstsheet");
		/*
		XSSFRow row0 = sheet0.createRow(0);
		XSSFCell cA = row0.createCell(0);
		XSSFCell cB = row0.createCell(1);
		cA.setCellValue("first cell");
		cB.setCellValue("second cell");
		*/
		for(int row=0;row<10;row++) {

			XSSFRow rows = sheet0.createRow(row);

			for(int col=0;col<10;col++) {

				XSSFCell cells = rows.createCell(col);
				cells.setCellValue((int)(Math.random()*100));
			}


		}

		File file = new File("C:\\Users\\vaunm\\OneDrive\\Desktop\\testexcel.xlsx");
		FileOutputStream fo = new FileOutputStream(file);
		workbook.write(fo);
		fo.close();





	}

}
