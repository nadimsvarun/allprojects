import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadExcelTest {

	public static void main(String[] args) throws EncryptedDocumentException, IOException {
		// TODO Auto-generated method stub

		File f = new File("C:\\Users\\vaunm\\OneDrive\\Desktop\\Data.xlsx");

		FileInputStream fs = new FileInputStream(f);

		Workbook wb = WorkbookFactory.create(fs);

		Sheet sheet0 = wb.getSheetAt(0);

		for(Row row:sheet0) {

			for(Cell cell:row) {

			if(cell.getCellType()==CellType.NUMERIC) {

				System.out.println((long)cell.getNumericCellValue());
			}else if(cell.getCellType()==CellType.STRING) {

				System.out.println(cell.getStringCellValue());
			}



			}
		}


	}

}
