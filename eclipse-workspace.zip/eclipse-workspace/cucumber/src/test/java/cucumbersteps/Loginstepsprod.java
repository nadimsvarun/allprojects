package cucumbersteps;

import io.cucumber.java.en.And;

public class Loginstepsprod {

	@And("user validates the captcha image")
	public void user_validates_the_captcha_image() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
}
