package cucumbersteps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Loginsteps {
	
	
	@Given("user navigates to the facebook website")
	public void user_navigates_to_the_facebook_website() {
	    
		System.out.println("@Given -- user navigates to the facebook website");
	}

	@When("user validates the home page title")
	public void user_validates_the_home_page_title() {
		System.out.println("@When -- user validates the home page title");
	}

	@Then("user enters {string} username")
	public void user_enters_username(String uname) {
		System.out.println("@Then -- user enters"+uname+" username ");
	}

	@And("user enters {string} password")
	public void user_enters_password(String pwd) {
		System.out.println("@And -- user enters"+pwd+"password");
	}

	@And("user clicks on login button")
	public void user_clicks_on_login_button() {
		System.out.println("@And -- user clicks on login button");
	   
	}


}
